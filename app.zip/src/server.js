const express = require("express");
const cors = require("cors");
const sequelize = require("./db");
const userRoutes = require("./routes/users");
const path = require("path");
require("dotenv").config();

const app = express();

// CORS — allow your frontend dev server
app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());

// Test DB connection
sequelize.authenticate()
  .then(() => console.log("DB connected"))
  .catch(err => console.error("DB connection failed:", err));

// Routes
app.use("/api/users", userRoutes);

// Simple test
//app.get("/", (req, res) => res.send("API is running"));

//where the react file live
//server.js is in /src
//react in /
const ROOT_DIR = path.join(__dirname, "..");
console.log(`I am ${ROOT_DIR}`);

//serve the static files in build
app.use(express.static(ROOT_DIR));

app.get("/", (req,res) => {
  res.sendFile(path.join(ROOT_DIR, "index.html"));
});

// Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
